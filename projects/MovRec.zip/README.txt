THIS IS A DEVELOPMENT PROJECT FOR PERSONAL USE ONLY 
No valuable information is stored on these databases

#Admin account for managing movie database

Username: Admin
Password: Admin123

#open start.bat to run