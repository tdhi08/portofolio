import sqlite3
import os

class DatabaseManager:

    def __init__(self, db_name="movies.db"):
        BASE_DIR = os.path.dirname(os.path.abspath(__file__))
        self.db_name = os.path.join(BASE_DIR, db_name)

    def connect(self):
        return sqlite3.connect(self.db_name)

    def create_tables(self):
        connect = self.connect()
        cur = connect.cursor()
        cur.execute("CREATE TABLE IF NOT EXISTS movie(Movie_ID INTEGER PRIMARY KEY AUTOINCREMENT, Title VARCHAR(255), Description VARCHAR(500), Age_Rating INTEGER, Runtime INTEGER, Genre VARCHAR(50), Poster VARCHAR(255))")
        cur.execute("CREATE TABLE IF NOT EXISTS users(User_ID INTEGER PRIMARY KEY AUTOINCREMENT, Username VARCHAR(255), Password VARCHAR(500), Is_Admin INTEGER DEFAULT 0)")
        cur.execute("""CREATE TABLE IF NOT EXISTS reviews(Review_ID INTEGER PRIMARY KEY AUTOINCREMENT,Movie_ID INTEGER,Username VARCHAR(255),Rating INTEGER,Review_Text VARCHAR(1000),Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP)""")
        try:
            cur.execute("ALTER TABLE movie ADD COLUMN Poster VARCHAR(255)")
        except:
            pass
        connect.commit()
        connect.close()

    def get_all_movies(self):
        connect = self.connect()
        cur = connect.cursor()

        result = cur.execute("SELECT * FROM movie")
        data = result.fetchall()

        connect.close()
        return data

    def add_movie(self, title, description, age_rating, runtime, genre, poster=""):
        connect = self.connect()
        cur = connect.cursor()
        cur.execute(
            "INSERT INTO movie (Title, Description, Age_Rating, Runtime, Genre, Poster) VALUES (?, ?, ?, ?, ?, ?)",
            (title, description, age_rating, runtime, genre, poster)
        )
        connect.commit()
        connect.close()

    def signup_user(self, username, password):
        connect = self.connect()
        cur = connect.cursor()

        cur.execute(f'SELECT Username FROM users WHERE Username = "{username}"')
        row = cur.fetchone()

        if row == None:
            cur.execute(f'INSERT INTO users (Username, Password) VALUES ("{username}", "{password}")')
            connect.commit()
            connect.close()
            return "success", 200
        else:
            connect.close()
            return "Username already exists.", 401

    def get_user_login(self, username):
        connect = self.connect()
        cur = connect.cursor()

        cur.execute(f'SELECT Password, Is_Admin FROM users WHERE Username = "{username}"')
        row = cur.fetchone()

        connect.close()
        return row
    
    def get_movie_by_title(self, title):
        connect = self.connect()
        cur = connect.cursor()
        cur.execute("SELECT * FROM movie WHERE Title = ?", (title,))
        row = cur.fetchone()
        connect.close()
        return row 
    
    def delete_movie(self, movie_id):
        connect = self.connect()
        cur = connect.cursor()
        cur.execute("DELETE FROM movie WHERE Movie_ID = ?", (movie_id,))
        connect.commit()
        connect.close()

    def add_review(self, movie_id, username, rating, review_text):
        connect = self.connect()
        cur = connect.cursor()
        cur.execute(
            "INSERT INTO reviews (Movie_ID, Username, Rating, Review_Text) VALUES (?, ?, ?, ?)",
            (movie_id, username, rating, review_text)
        )
        connect.commit()
        connect.close()

    def get_reviews(self, movie_id):
        connect = self.connect()
        cur = connect.cursor()
        cur.execute(
            "SELECT Username, Rating, Review_Text, Date FROM reviews WHERE Movie_ID = ? ORDER BY Date DESC",
            (movie_id,)
        )
        rows = cur.fetchall()
        connect.close()
        return rows
    
    
