from flask import Flask, request, jsonify, send_from_directory
from db import DatabaseManager
import secrets
import os

app = Flask(__name__)
database = DatabaseManager()
database.create_tables()
token_pool = []

UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "posters")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/")
def hello_world():
    return str(database.get_all_movies())

@app.route("/add_movie", methods=["POST"])
def AddMovie():
    title       = request.form.get("title")
    description = request.form.get("description")
    age_rating  = request.form.get("age_rating")
    runtime     = request.form.get("runtime")
    genre       = request.form.get("genre")

    poster_filename = ""
    file = request.files.get("poster")
    if file and allowed_file(file.filename):
        from werkzeug.utils import secure_filename
        poster_filename = secure_filename(file.filename)
        file.save(os.path.join(UPLOAD_FOLDER, poster_filename))

    database.add_movie(title, description, age_rating, runtime, genre, poster_filename)
    return "success", 200

@app.route("/get_movie", methods=["GET"])
def get_movie():
    title = request.args.get("title")
    if not title:
        return jsonify({"error": "No title provided"}), 400
    row = database.get_movie_by_title(title)
    if row is None:
        return jsonify({"error": "Movie not found"}), 404
    return jsonify({
        "movie_id":    row[0],
        "title":       row[1],
        "description": row[2],
        "age_rating":  row[3],
        "runtime":     row[4],
        "genre":       row[5],
        "poster":      row[6] if len(row) > 6 else ""
    })

@app.route("/get_poster/<filename>", methods=["GET"])
def get_poster(filename):
    return send_from_directory(UPLOAD_FOLDER, filename)

@app.route("/signup", methods=["POST"])
def signup():
    username = request.form.get("Username")
    password = request.form.get("Password")
    return database.signup_user(username, password)

@app.route("/login", methods=["POST"])
def login():
    username = request.form.get("Username")
    password = request.form.get("Password")
    row = database.get_user_login(username)
    if row is None or row[0] is None:
        return "Invalid username or password", 401
    elif row[0] == password:
        token = secrets.token_urlsafe(32)
        token_pool.append({"username": username, "token": token, "is_admin": row[1]})
        return jsonify(token=token, is_admin=row[1])
    else:
        return "Invalid username or password", 401
    
@app.route("/get_all_movies", methods=["GET"])
def get_all_movies():
    rows = database.get_all_movies()
    movies = [
        {
            "movie_id":    row[0],
            "title":       row[1],
            "description": row[2],
            "age_rating":  row[3],
            "runtime":     row[4],
            "genre":       row[5],
            "poster":      row[6] if len(row) > 6 else ""
        }
        for row in rows
    ]
    return jsonify(movies)

@app.route("/delete_movie", methods=["DELETE"])
def delete_movie():
    movie_id = request.form.get("movie_id")
    if not movie_id:
        return jsonify({"error": "No movie_id provided"}), 400
    database.delete_movie(int(movie_id))
    return "success", 200

@app.route("/recommend_movies", methods=["GET"])
def recommend_movies():
    genre = request.args.get("genre", "").lower()
    runtime = request.args.get("runtime")
    age_rating = request.args.get("age_rating")

    runtime_val = int(runtime) if runtime else None
    age_val = int(age_rating) if age_rating else None

    rows = database.get_all_movies()
    filtered = []

    for row in rows:
        movie = {
            "movie_id": row[0],
            "title": row[1],
            "description": row[2],
            "age_rating": row[3],
            "runtime": row[4],
            "genre": row[5],
            "poster": row[6] if len(row) > 6 else ""
        }

        if genre and genre not in movie["genre"].lower():
            continue

        if runtime_val:
            min_runtime = runtime_val - 20
            max_runtime = runtime_val + 30

            if not (min_runtime <= int(movie["runtime"]) <= max_runtime):
                continue

        if age_val and int(movie["age_rating"]) > age_val:
            continue

        filtered.append(movie)

    return jsonify(filtered)

@app.route("/add_review", methods=["POST"])
def add_review():
    movie_id    = request.form.get("movie_id")
    username    = request.form.get("username")
    rating      = request.form.get("rating")
    review_text = request.form.get("review_text")

    if not all([movie_id, username, rating, review_text]):
        return jsonify({"error": "Missing fields"}), 400
    if not str(rating).isdigit() or not (1 <= int(rating) <= 5):
        return jsonify({"error": "Rating must be 1–5"}), 400

    database.add_review(int(movie_id), username, int(rating), review_text)
    return "success", 200

@app.route("/get_reviews", methods=["GET"])
def get_reviews():
    movie_id = request.args.get("movie_id")
    if not movie_id:
        return jsonify({"error": "No movie_id provided"}), 400
    rows = database.get_reviews(int(movie_id))
    reviews = [
        {"username": r[0], "rating": r[1], "review_text": r[2], "date": r[3]}
        for r in rows
    ]
    return jsonify(reviews)

if __name__ == "__main__":
    app.run()